const uint32_t a_dns_server_numeric = a_dns_server.ipv4_numeric();
